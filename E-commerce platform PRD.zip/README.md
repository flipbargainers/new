
  # E-commerce platform PRD

  This is a code bundle for E-commerce platform PRD. The original project is available at https://www.figma.com/design/vqu7mw4pED3QlPR0keQrH1/E-commerce-platform-PRD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  