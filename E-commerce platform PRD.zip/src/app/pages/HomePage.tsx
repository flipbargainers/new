import { Link } from 'react-router';
import { FannedBanner } from '../components/FannedBanner';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/products';
import { ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';

export function HomePage() {
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 4);
  const newArrivals = products.filter((p) => p.isNew).slice(0, 4);

  const categories = [
    {
      name: 'Best Sellers',
      image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800',
      link: '/products/all?filter=bestseller',
    },
    {
      name: 'New Arrivals',
      image: 'https://images.unsplash.com/photo-1558769132-cb1aea3c8565?w=800',
      link: '/products/all?filter=new',
    },
    {
      name: 'Seasonal Collection',
      image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800',
      link: '/products/women',
    },
    {
      name: 'Trending Shoes',
      image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800',
      link: '/products/all?subcategory=shoes',
    },
  ];

  return (
    <div>
      {/* Hero Banner */}
      <FannedBanner />

      {/* Category Grid */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-8 text-center">Shop by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link
              key={category.name}
              to={category.link}
              className="group relative overflow-hidden rounded-lg aspect-[3/4] shadow-lg hover:shadow-xl transition-shadow"
            >
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white w-full">
                  <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                  <span className="inline-flex items-center gap-2 text-sm">
                    Shop Now <ArrowRight size={16} />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Best Sellers */}
      <section className="container mx-auto px-4 py-16 bg-gray-50">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Best Sellers</h2>
          <Button asChild variant="outline">
            <Link to="/products/all?filter=bestseller">
              View All <ArrowRight className="ml-2" size={16} />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      {newArrivals.length > 0 && (
        <section className="container mx-auto px-4 py-16">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">New Arrivals</h2>
            <Button asChild variant="outline">
              <Link to="/products/all?filter=new">
                View All <ArrowRight className="ml-2" size={16} />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* Featured Banner */}
      <section className="relative h-[400px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600"
          alt="Featured"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white space-y-4">
            <h2 className="text-5xl font-bold">Spring Sale</h2>
            <p className="text-xl">Up to 50% off selected items</p>
            <Button asChild size="lg" className="bg-white text-black hover:bg-gray-200">
              <Link to="/products/sale">Shop Sale</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="bg-black text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Community</h2>
          <p className="text-lg mb-8 text-gray-300">
            Sign up for exclusive offers and get 10% off your first order
          </p>
          <form className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg text-black"
            />
            <Button type="submit" size="lg" className="bg-white text-black hover:bg-gray-200">
              Subscribe
            </Button>
          </form>
        </div>
      </section>
    </div>
  );
}
