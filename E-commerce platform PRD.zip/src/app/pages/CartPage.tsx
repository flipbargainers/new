import { Link } from 'react-router';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';

export function CartPage() {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useCart();

  const shipping = cartTotal > 100 ? 0 : 10;
  const tax = cartTotal * 0.08;
  const total = cartTotal + shipping + tax;

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center space-y-6">
          <div className="w-24 h-24 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
            <ShoppingBag size={48} className="text-gray-400" />
          </div>
          <h1 className="text-3xl font-bold">Your cart is empty</h1>
          <p className="text-gray-600">
            Looks like you haven't added anything to your cart yet.
          </p>
          <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800">
            <Link to="/products/all">Continue Shopping</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <div
              key={`${item.productId}-${item.size}-${item.color}`}
              className="flex gap-4 bg-white p-4 rounded-lg border"
            >
              {/* Product Image */}
              <Link to={`/product/${item.productId}`} className="flex-shrink-0">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-24 h-32 object-cover rounded"
                />
              </Link>

              {/* Product Details */}
              <div className="flex-1 min-w-0">
                <Link to={`/product/${item.productId}`}>
                  <h3 className="font-semibold mb-1 hover:underline">{item.name}</h3>
                </Link>
                <p className="text-sm text-gray-600 mb-2">
                  Size: {item.size} | Color: {item.color}
                </p>
                <p className="font-semibold">${item.price.toFixed(2)}</p>

                {/* Quantity Controls */}
                <div className="flex items-center gap-3 mt-4">
                  <button
                    onClick={() =>
                      updateQuantity(item.productId, item.size, item.color, item.quantity - 1)
                    }
                    className="w-8 h-8 border border-gray-300 rounded hover:bg-gray-100 flex items-center justify-center"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="w-8 text-center font-medium">{item.quantity}</span>
                  <button
                    onClick={() =>
                      updateQuantity(item.productId, item.size, item.color, item.quantity + 1)
                    }
                    className="w-8 h-8 border border-gray-300 rounded hover:bg-gray-100 flex items-center justify-center"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Remove Button & Subtotal */}
              <div className="flex flex-col items-end justify-between">
                <button
                  onClick={() => removeFromCart(item.productId, item.size, item.color)}
                  className="text-gray-400 hover:text-red-600 transition-colors"
                >
                  <Trash2 size={20} />
                </button>
                <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-gray-50 rounded-lg p-6 sticky top-24">
            <h2 className="text-xl font-bold mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal ({cart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Estimated Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="border-t pt-3 flex justify-between text-xl font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>

            {shipping > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 text-sm text-blue-800">
                Add ${(100 - cartTotal).toFixed(2)} more to get FREE shipping!
              </div>
            )}

            <Button asChild className="w-full bg-black text-white hover:bg-gray-800 h-12 text-lg mb-3">
              <Link to="/checkout">Proceed to Checkout</Link>
            </Button>

            <Button asChild variant="outline" className="w-full">
              <Link to="/products/all">Continue Shopping</Link>
            </Button>

            {/* Payment Methods */}
            <div className="mt-6 pt-6 border-t">
              <p className="text-sm text-gray-600 mb-3">We accept:</p>
              <div className="flex flex-wrap gap-2">
                <div className="px-3 py-2 bg-white border rounded text-xs font-semibold">
                  VISA
                </div>
                <div className="px-3 py-2 bg-white border rounded text-xs font-semibold">
                  MASTERCARD
                </div>
                <div className="px-3 py-2 bg-white border rounded text-xs font-semibold">
                  AMEX
                </div>
                <div className="px-3 py-2 bg-white border rounded text-xs font-semibold">
                  PayPal
                </div>
                <div className="px-3 py-2 bg-white border rounded text-xs font-semibold">
                  Apple Pay
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
