import { useState, useMemo } from 'react';
import { useParams, useSearchParams } from 'react-router';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/products';
import { Slider } from '../components/ui/slider';
import { Checkbox } from '../components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { SlidersHorizontal, X } from 'lucide-react';
import { Button } from '../components/ui/button';

export function ProductListingPage() {
  const { category } = useParams();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  const subcategoryParam = searchParams.get('subcategory') || '';
  const filterParam = searchParams.get('filter') || '';

  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [selectedFabrics, setSelectedFabrics] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);

  // Get unique values for filters
  const allSizes = Array.from(new Set(products.flatMap((p) => p.sizes)));
  const allColors = Array.from(new Set(products.flatMap((p) => p.colors)));
  const allFabrics = Array.from(new Set(products.map((p) => p.fabric).filter(Boolean))) as string[];

  // Filter products
  const filteredProducts = useMemo(() => {
    let filtered = products;

    // Filter by category
    if (category && category !== 'all') {
      if (category === 'sale') {
        // For demo, show some random products as sale
        filtered = filtered.slice(0, 8);
      } else {
        filtered = filtered.filter((p) => p.category === category);
      }
    }

    // Filter by subcategory
    if (subcategoryParam) {
      filtered = filtered.filter((p) => p.subcategory === subcategoryParam);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((p) =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by special flags
    if (filterParam === 'bestseller') {
      filtered = filtered.filter((p) => p.isBestSeller);
    } else if (filterParam === 'new') {
      filtered = filtered.filter((p) => p.isNew);
    }

    // Filter by size
    if (selectedSizes.length > 0) {
      filtered = filtered.filter((p) =>
        p.sizes.some((size) => selectedSizes.includes(size))
      );
    }

    // Filter by color
    if (selectedColors.length > 0) {
      filtered = filtered.filter((p) =>
        p.colors.some((color) => selectedColors.includes(color))
      );
    }

    // Filter by price
    filtered = filtered.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    // Filter by fabric
    if (selectedFabrics.length > 0) {
      filtered = filtered.filter((p) =>
        p.fabric && selectedFabrics.includes(p.fabric)
      );
    }

    // Sort
    switch (sortBy) {
      case 'price-low':
        filtered = [...filtered].sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered = [...filtered].sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        filtered = [...filtered].sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'rating':
        filtered = [...filtered].sort((a, b) => b.rating - a.rating);
        break;
    }

    return filtered;
  }, [
    category,
    subcategoryParam,
    searchQuery,
    filterParam,
    selectedSizes,
    selectedColors,
    priceRange,
    selectedFabrics,
    sortBy,
  ]);

  const toggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const toggleColor = (color: string) => {
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]
    );
  };

  const toggleFabric = (fabric: string) => {
    setSelectedFabrics((prev) =>
      prev.includes(fabric) ? prev.filter((f) => f !== fabric) : [...prev, fabric]
    );
  };

  const clearFilters = () => {
    setSelectedSizes([]);
    setSelectedColors([]);
    setPriceRange([0, 500]);
    setSelectedFabrics([]);
  };

  const hasActiveFilters =
    selectedSizes.length > 0 ||
    selectedColors.length > 0 ||
    selectedFabrics.length > 0 ||
    priceRange[0] !== 0 ||
    priceRange[1] !== 500;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold capitalize mb-2">
          {searchQuery
            ? `Search Results for "${searchQuery}"`
            : filterParam
            ? filterParam === 'bestseller'
              ? 'Best Sellers'
              : 'New Arrivals'
            : category === 'all'
            ? 'All Products'
            : category || 'Products'}
        </h1>
        <p className="text-gray-600">{filteredProducts.length} products found</p>
      </div>

      <div className="flex gap-8">
        {/* Sidebar Filters */}
        <aside
          className={`${
            showFilters ? 'fixed inset-0 z-50 bg-white p-6 overflow-y-auto' : 'hidden'
          } lg:block lg:static lg:w-64 space-y-6`}
        >
          <div className="flex items-center justify-between lg:hidden mb-6">
            <h2 className="text-xl font-bold">Filters</h2>
            <button onClick={() => setShowFilters(false)}>
              <X size={24} />
            </button>
          </div>

          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearFilters}
              className="w-full"
            >
              Clear All Filters
            </Button>
          )}

          {/* Size Filter */}
          <div>
            <h3 className="font-semibold mb-3">Size</h3>
            <div className="space-y-2">
              {allSizes.slice(0, 10).map((size) => (
                <label key={size} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={selectedSizes.includes(size)}
                    onCheckedChange={() => toggleSize(size)}
                  />
                  <span className="text-sm">{size}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Color Filter */}
          <div>
            <h3 className="font-semibold mb-3">Color</h3>
            <div className="space-y-2">
              {allColors.slice(0, 10).map((color) => (
                <label key={color} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={selectedColors.includes(color)}
                    onCheckedChange={() => toggleColor(color)}
                  />
                  <span className="text-sm">{color}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range Filter */}
          <div>
            <h3 className="font-semibold mb-3">Price Range</h3>
            <div className="space-y-4">
              <Slider
                min={0}
                max={500}
                step={10}
                value={priceRange}
                onValueChange={setPriceRange}
                className="w-full"
              />
              <div className="flex justify-between text-sm">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
          </div>

          {/* Fabric Filter */}
          {allFabrics.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3">Fabric</h3>
              <div className="space-y-2">
                {allFabrics.map((fabric) => (
                  <label key={fabric} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={selectedFabrics.includes(fabric)}
                      onCheckedChange={() => toggleFabric(fabric)}
                    />
                    <span className="text-sm">{fabric}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Sort Bar */}
          <div className="flex items-center justify-between mb-6 pb-4 border-b">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(true)}
              className="lg:hidden gap-2"
            >
              <SlidersHorizontal size={16} />
              Filters
            </Button>

            <div className="flex items-center gap-4 ml-auto">
              <span className="text-sm text-gray-600">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="rating">Best Rated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Product Grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-gray-600">No products found</p>
              <Button onClick={clearFilters} variant="outline" className="mt-4">
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
