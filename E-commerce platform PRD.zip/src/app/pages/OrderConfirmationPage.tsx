import { Link } from 'react-router';
import { Button } from '../components/ui/button';
import { CheckCircle, Mail, Package } from 'lucide-react';

export function OrderConfirmationPage() {
  const orderNumber = `FH-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center space-y-6">
        {/* Success Icon */}
        <div className="w-24 h-24 mx-auto bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle size={56} className="text-green-600" />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-bold">Order Confirmed!</h1>

        {/* Subtitle */}
        <p className="text-xl text-gray-600">
          Thank you for your purchase. Your order has been successfully placed.
        </p>

        {/* Order Number */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
          <p className="text-sm text-gray-600 mb-2">Order Number</p>
          <p className="text-2xl font-bold">{orderNumber}</p>
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-left">
            <div className="flex items-start gap-4">
              <Mail className="text-blue-600 flex-shrink-0 mt-1" size={24} />
              <div>
                <h3 className="font-semibold mb-2">Order Confirmation Email</h3>
                <p className="text-sm text-gray-600">
                  We've sent a confirmation email with your order details and tracking information.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 text-left">
            <div className="flex items-start gap-4">
              <Package className="text-purple-600 flex-shrink-0 mt-1" size={24} />
              <div>
                <h3 className="font-semibold mb-2">Estimated Delivery</h3>
                <p className="text-sm text-gray-600">
                  Your order will arrive in 5-7 business days. Track your shipment anytime.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800">
            <Link to="/products/all">Continue Shopping</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/">Back to Home</Link>
          </Button>
        </div>

        {/* Support */}
        <div className="mt-12 pt-8 border-t">
          <p className="text-sm text-gray-600">
            Need help? Contact our{' '}
            <Link to="/contact" className="text-black underline">
              customer support
            </Link>{' '}
            team
          </p>
        </div>
      </div>
    </div>
  );
}
