export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  subcategory: string;
  images: string[];
  description: string;
  sizes: string[];
  colors: string[];
  fabric?: string;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  isNew?: boolean;
  isBestSeller?: boolean;
  relatedProducts?: string[];
}

export const products: Product[] = [
  // Women's Clothing
  {
    id: "1",
    name: "Classic White Button-Up Shirt",
    price: 79.99,
    category: "women",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1624206112918-ad87355f60e7?w=800",
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800"
    ],
    description: "Timeless white button-up shirt crafted from premium cotton. Perfect for both professional and casual settings.",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["White", "Cream"],
    fabric: "100% Cotton",
    rating: 4.5,
    reviewCount: 128,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["2", "5", "15"]
  },
  {
    id: "2",
    name: "High-Waisted Denim Jeans",
    price: 89.99,
    category: "women",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800",
      "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=800"
    ],
    description: "Flattering high-waisted denim with stretch comfort. Classic blue wash suitable for any occasion.",
    sizes: ["24", "26", "28", "30", "32"],
    colors: ["Blue", "Black", "Light Blue"],
    fabric: "98% Cotton, 2% Elastane",
    rating: 4.7,
    reviewCount: 256,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["1", "3", "16"]
  },
  {
    id: "3",
    name: "Floral Summer Dress",
    price: 129.99,
    category: "women",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800",
      "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=800"
    ],
    description: "Lightweight floral dress perfect for summer days. Features a flattering A-line silhouette.",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Floral Pink", "Floral Blue"],
    fabric: "Rayon Blend",
    rating: 4.6,
    reviewCount: 89,
    inStock: true,
    isNew: true,
    relatedProducts: ["4", "17", "18"]
  },
  {
    id: "4",
    name: "Cozy Knit Sweater",
    price: 99.99,
    category: "women",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800"
    ],
    description: "Soft and cozy knit sweater for those chilly days. Oversized fit for maximum comfort.",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Beige", "Grey", "Navy"],
    fabric: "Wool Blend",
    rating: 4.8,
    reviewCount: 312,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["2", "3", "5"]
  },

  // Women's Shoes
  {
    id: "5",
    name: "White Leather Sneakers",
    price: 119.99,
    category: "women",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800",
      "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=800"
    ],
    description: "Minimalist white leather sneakers that go with everything. Premium quality construction.",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["White", "Off-White"],
    rating: 4.9,
    reviewCount: 445,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["1", "2", "6"]
  },
  {
    id: "6",
    name: "Black Ankle Boots",
    price: 159.99,
    category: "women",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800",
      "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=800"
    ],
    description: "Classic black ankle boots with a block heel. Perfect for year-round styling.",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["Black", "Brown"],
    rating: 4.7,
    reviewCount: 198,
    inStock: true,
    relatedProducts: ["4", "7", "2"]
  },

  // Men's Clothing
  {
    id: "7",
    name: "Classic Crew Neck T-Shirt",
    price: 29.99,
    category: "men",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800"
    ],
    description: "Essential crew neck t-shirt in premium cotton. A wardrobe staple.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Black", "Grey", "Navy"],
    fabric: "100% Cotton",
    rating: 4.6,
    reviewCount: 523,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["8", "9", "10"]
  },
  {
    id: "8",
    name: "Slim Fit Chino Pants",
    price: 79.99,
    category: "men",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=800"
    ],
    description: "Modern slim fit chinos with stretch comfort. Dress up or down.",
    sizes: ["28", "30", "32", "34", "36", "38"],
    colors: ["Khaki", "Navy", "Grey", "Black"],
    fabric: "Cotton Twill Stretch",
    rating: 4.5,
    reviewCount: 276,
    inStock: true,
    relatedProducts: ["7", "11", "12"]
  },
  {
    id: "9",
    name: "Casual Denim Jacket",
    price: 119.99,
    category: "men",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800",
      "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800"
    ],
    description: "Vintage-inspired denim jacket. Perfect layering piece for any season.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Blue Denim", "Black Denim"],
    fabric: "100% Cotton Denim",
    rating: 4.8,
    reviewCount: 412,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["7", "8", "10"]
  },
  {
    id: "10",
    name: "Tailored Dress Shirt",
    price: 89.99,
    category: "men",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800",
      "https://images.unsplash.com/photo-1603252109303-2751441dd157?w=800"
    ],
    description: "Crisp tailored dress shirt for the modern professional. Non-iron finish.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Light Blue", "Pink"],
    fabric: "Cotton Blend",
    rating: 4.7,
    reviewCount: 189,
    inStock: true,
    relatedProducts: ["8", "11", "13"]
  },

  // Men's Shoes
  {
    id: "11",
    name: "Brown Leather Oxford Shoes",
    price: 179.99,
    category: "men",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1614252368738-5c0a2f5d3173?w=800",
      "https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=800"
    ],
    description: "Classic brown leather oxfords. Handcrafted quality for the discerning gentleman.",
    sizes: ["7", "8", "9", "10", "11", "12"],
    colors: ["Brown", "Black"],
    rating: 4.9,
    reviewCount: 234,
    inStock: true,
    isBestSeller: true,
    relatedProducts: ["10", "8", "12"]
  },
  {
    id: "12",
    name: "Running Sneakers",
    price: 139.99,
    category: "men",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=800"
    ],
    description: "High-performance running sneakers with responsive cushioning.",
    sizes: ["7", "8", "9", "10", "11", "12", "13"],
    colors: ["Black", "White", "Grey"],
    rating: 4.6,
    reviewCount: 567,
    inStock: true,
    relatedProducts: ["7", "13", "14"]
  },

  // Kids
  {
    id: "13",
    name: "Kids Graphic T-Shirt",
    price: 19.99,
    category: "kids",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=800",
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800"
    ],
    description: "Fun graphic t-shirt for kids. Soft cotton fabric.",
    sizes: ["2T", "3T", "4T", "5T", "6", "7", "8"],
    colors: ["Blue", "Red", "Green"],
    fabric: "100% Cotton",
    rating: 4.5,
    reviewCount: 156,
    inStock: true,
    relatedProducts: ["14", "15", "16"]
  },
  {
    id: "14",
    name: "Kids Sneakers",
    price: 59.99,
    category: "kids",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1514989940723-e8e51635b782?w=800",
      "https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=800"
    ],
    description: "Comfortable sneakers for active kids. Durable and stylish.",
    sizes: ["10", "11", "12", "13", "1", "2", "3"],
    colors: ["Multi", "Blue", "Pink"],
    rating: 4.7,
    reviewCount: 289,
    inStock: true,
    relatedProducts: ["13", "15", "16"]
  },

  // Accessories
  {
    id: "15",
    name: "Leather Crossbody Bag",
    price: 149.99,
    category: "women",
    subcategory: "accessories",
    images: [
      "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800",
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800"
    ],
    description: "Elegant leather crossbody bag with adjustable strap. Perfect everyday companion.",
    sizes: ["One Size"],
    colors: ["Black", "Brown", "Tan"],
    rating: 4.8,
    reviewCount: 167,
    inStock: true,
    relatedProducts: ["1", "5", "6"]
  },
  {
    id: "16",
    name: "Classic Leather Belt",
    price: 49.99,
    category: "men",
    subcategory: "accessories",
    images: [
      "https://images.unsplash.com/photo-1624222247344-550fb60583f2?w=800",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800"
    ],
    description: "Genuine leather belt with polished buckle. Timeless accessory.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Brown"],
    rating: 4.6,
    reviewCount: 234,
    inStock: true,
    relatedProducts: ["8", "10", "11"]
  },

  // Sale Items
  {
    id: "17",
    name: "Striped Summer Top",
    price: 39.99,
    category: "women",
    subcategory: "clothing",
    images: [
      "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800",
      "https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=800"
    ],
    description: "Casual striped top perfect for summer. Lightweight and breathable.",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Navy/White", "Red/White"],
    fabric: "Linen Blend",
    rating: 4.4,
    reviewCount: 78,
    inStock: true,
    relatedProducts: ["2", "3", "18"]
  },
  {
    id: "18",
    name: "Suede Loafers",
    price: 99.99,
    category: "women",
    subcategory: "shoes",
    images: [
      "https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=800",
      "https://images.unsplash.com/photo-1582897085656-c636d006a246?w=800"
    ],
    description: "Comfortable suede loafers for everyday wear. Versatile styling.",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["Tan", "Navy", "Black"],
    rating: 4.5,
    reviewCount: 123,
    inStock: true,
    relatedProducts: ["1", "17", "15"]
  }
];

export const heroImages = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800",
    title: "Spring Collection",
    subtitle: "New Arrivals",
    link: "/products/women"
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800",
    title: "Summer Essentials",
    subtitle: "Shop Now",
    link: "/products/women"
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=800",
    title: "Best Sellers",
    subtitle: "Trending Styles",
    link: "/products/all"
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800",
    title: "Men's Fashion",
    subtitle: "Discover More",
    link: "/products/men"
  }
];
