import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ShoppingCart, User, Search, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Button } from './ui/button';
import { Input } from './ui/input';

export function Header() {
  const { cartCount } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products/all?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
    }
  };

  const megaMenuData = {
    women: {
      clothing: ['Dresses', 'Tops', 'Jeans', 'Sweaters', 'Jackets'],
      shoes: ['Sneakers', 'Boots', 'Heels', 'Flats'],
      accessories: ['Bags', 'Jewelry', 'Belts', 'Scarves']
    },
    men: {
      clothing: ['T-Shirts', 'Shirts', 'Pants', 'Jackets', 'Suits'],
      shoes: ['Sneakers', 'Dress Shoes', 'Boots', 'Loafers'],
      accessories: ['Belts', 'Bags', 'Watches', 'Wallets']
    },
    kids: {
      clothing: ['T-Shirts', 'Dresses', 'Pants', 'Jackets'],
      shoes: ['Sneakers', 'Sandals', 'Boots'],
      accessories: ['Bags', 'Hats']
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b">
      {/* Top Bar */}
      <div className="bg-black text-white text-sm py-2">
        <div className="container mx-auto px-4 text-center">
          Free Shipping on Orders Over $100 | Sign up for 10% off your first order
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Mobile Menu Button */}
          <button
            className="lg:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Logo */}
          <Link to="/" className="text-2xl font-bold">
            FashionHub
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {(['women', 'men', 'kids', 'sale'] as const).map((category) => (
              <div
                key={category}
                className="relative"
                onMouseEnter={() => setActiveMenu(category)}
                onMouseLeave={() => setActiveMenu(null)}
              >
                <Link
                  to={`/products/${category}`}
                  className="text-sm font-medium uppercase hover:text-gray-600 transition-colors"
                >
                  {category}
                </Link>

                {/* Mega Menu */}
                {activeMenu === category && category !== 'sale' && (
                  <div className="absolute left-0 top-full pt-4 w-[600px]">
                    <div className="bg-white border shadow-lg rounded-lg p-6 grid grid-cols-3 gap-6">
                      {Object.entries(megaMenuData[category]).map(([subcategory, items]) => (
                        <div key={subcategory}>
                          <h3 className="font-semibold mb-3 capitalize">{subcategory}</h3>
                          <ul className="space-y-2">
                            {items.map((item) => (
                              <li key={item}>
                                <Link
                                  to={`/products/${category}?subcategory=${subcategory}`}
                                  className="text-sm text-gray-600 hover:text-black"
                                >
                                  {item}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                      <div className="col-span-3 mt-4 pt-4 border-t">
                        <img
                          src={`https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&h=200&fit=crop`}
                          alt="Featured"
                          className="w-full h-32 object-cover rounded"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <Input
                type="text"
                placeholder="Search for products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </form>

          {/* Right Icons */}
          <div className="flex items-center gap-4">
            <Link to="/cart" className="relative">
              <ShoppingCart size={24} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-black text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <button>
              <User size={24} />
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-4">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </form>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t bg-white">
          <nav className="container mx-auto px-4 py-4">
            <ul className="space-y-3">
              {['women', 'men', 'kids', 'sale'].map((category) => (
                <li key={category}>
                  <Link
                    to={`/products/${category}`}
                    className="block text-sm font-medium uppercase py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {category}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
}
