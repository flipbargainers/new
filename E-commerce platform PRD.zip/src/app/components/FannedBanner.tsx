import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import { heroImages } from '../data/products';
import { Button } from './ui/button';

export function FannedBanner() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % heroImages.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + heroImages.length) % heroImages.length);
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % heroImages.length);
  };

  return (
    <div
      className="relative bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Text Content */}
          <div className="space-y-6 z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <span className="inline-block px-4 py-1 bg-black text-white text-sm mb-4">
                  {heroImages[activeIndex].subtitle}
                </span>
                <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                  {heroImages[activeIndex].title}
                </h1>
                <p className="text-xl text-gray-600 mb-8">
                  Discover the latest trends and timeless classics. Shop our curated collection of premium fashion.
                </p>
                <div className="flex gap-4">
                  <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800">
                    <Link to={heroImages[activeIndex].link}>Shop Now</Link>
                  </Button>
                  <Button asChild size="lg" variant="outline">
                    <Link to="/products/all">Explore All</Link>
                  </Button>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation Controls */}
            <div className="flex items-center gap-4 pt-8">
              <button
                onClick={handlePrev}
                className="p-2 border border-gray-300 rounded-full hover:bg-gray-100 transition-colors"
                aria-label="Previous slide"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={handleNext}
                className="p-2 border border-gray-300 rounded-full hover:bg-gray-100 transition-colors"
                aria-label="Next slide"
              >
                <ChevronRight size={24} />
              </button>

              {/* Dot Indicators */}
              <div className="flex gap-2 ml-4">
                {heroImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === activeIndex ? 'bg-black w-8' : 'bg-gray-300'
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Right Side - Fanned Images */}
          <div className="relative h-[500px] lg:h-[600px]">
            <div className="absolute inset-0 flex items-center justify-center lg:justify-end">
              <AnimatePresence mode="sync">
                {heroImages.map((item, index) => {
                  // Calculate position in the fan
                  const offset = index - activeIndex;
                  const absOffset = Math.abs(offset);
                  
                  // Only show active image on mobile, 3 images on desktop
                  if (absOffset > 0 && window.innerWidth < 1024) return null;
                  if (absOffset > 2) return null;

                  // Calculate rotation based on position (no rotation on mobile)
                  const rotation = window.innerWidth >= 1024 ? offset * 5 : 0;
                  const zIndex = 4 - absOffset; // Active image on top
                  const scale = 1 - absOffset * 0.05; // Slight scale difference
                  const xOffset = window.innerWidth >= 1024 ? offset * 60 : 0; // No offset on mobile

                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{
                        opacity: 1,
                        scale,
                        rotate: rotation,
                        x: xOffset,
                        zIndex,
                      }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.6, ease: 'easeInOut' }}
                      className="absolute w-[280px] h-[400px] lg:w-[320px] lg:h-[480px]"
                      style={{
                        transformOrigin: 'center center',
                      }}
                    >
                      <Link to={item.link}>
                        <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-2xl">
                          <img
                            src={item.image}
                            alt={item.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                        </div>
                      </Link>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}