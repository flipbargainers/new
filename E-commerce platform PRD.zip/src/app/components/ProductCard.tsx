import { useState } from 'react';
import { Link } from 'react-router';
import { Star, Eye } from 'lucide-react';
import { motion } from 'motion/react';
import { Product } from '../data/products';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [quickViewOpen, setQuickViewOpen] = useState(false);

  return (
    <>
      <motion.div
        className="group relative"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        whileHover={{ y: -4 }}
        transition={{ duration: 0.2 }}
      >
        <Link to={`/product/${product.id}`}>
          <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-gray-100 mb-4">
            {/* Main Image */}
            <img
              src={product.images[0]}
              alt={product.name}
              className={`w-full h-full object-cover transition-opacity duration-300 ${
                isHovered && product.images[1] ? 'opacity-0' : 'opacity-100'
              }`}
            />

            {/* Hover Image */}
            {product.images[1] && (
              <img
                src={product.images[1]}
                alt={product.name}
                className="absolute inset-0 w-full h-full object-cover transition-opacity duration-300"
                style={{ opacity: isHovered ? 1 : 0 }}
              />
            )}

            {/* Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              {product.isNew && (
                <span className="bg-black text-white text-xs px-3 py-1 rounded-full">
                  New
                </span>
              )}
              {product.isBestSeller && (
                <span className="bg-white text-black text-xs px-3 py-1 rounded-full">
                  Best Seller
                </span>
              )}
            </div>

            {/* Quick View Button */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              className="absolute inset-0 flex items-center justify-center bg-black/20"
            >
              <Button
                variant="secondary"
                size="sm"
                onClick={(e) => {
                  e.preventDefault();
                  setQuickViewOpen(true);
                }}
                className="gap-2"
              >
                <Eye size={16} />
                Quick View
              </Button>
            </motion.div>
          </div>
        </Link>

        {/* Product Info */}
        <div className="space-y-2">
          <Link to={`/product/${product.id}`}>
            <h3 className="font-medium text-sm hover:underline">{product.name}</h3>
          </Link>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={14}
                  className={
                    i < Math.floor(product.rating)
                      ? 'fill-black text-black'
                      : 'text-gray-300'
                  }
                />
              ))}
            </div>
            <span className="text-xs text-gray-500">({product.reviewCount})</span>
          </div>

          {/* Price */}
          <p className="font-semibold">${product.price.toFixed(2)}</p>

          {/* Colors */}
          {product.colors.length > 0 && (
            <div className="flex gap-1">
              {product.colors.slice(0, 5).map((color, index) => (
                <div
                  key={index}
                  className="w-4 h-4 rounded-full border border-gray-300"
                  style={{
                    backgroundColor: color.toLowerCase().includes('white')
                      ? '#fff'
                      : color.toLowerCase().includes('black')
                      ? '#000'
                      : color.toLowerCase().includes('blue')
                      ? '#3b82f6'
                      : color.toLowerCase().includes('red')
                      ? '#ef4444'
                      : color.toLowerCase().includes('grey') || color.toLowerCase().includes('gray')
                      ? '#9ca3af'
                      : color.toLowerCase().includes('pink')
                      ? '#ec4899'
                      : color.toLowerCase().includes('green')
                      ? '#10b981'
                      : color.toLowerCase().includes('brown')
                      ? '#92400e'
                      : color.toLowerCase().includes('beige') || color.toLowerCase().includes('tan') || color.toLowerCase().includes('cream')
                      ? '#d4b896'
                      : color.toLowerCase().includes('navy')
                      ? '#1e3a8a'
                      : '#6b7280',
                  }}
                  title={color}
                />
              ))}
            </div>
          )}
        </div>
      </motion.div>

      {/* Quick View Modal */}
      <Dialog open={quickViewOpen} onOpenChange={setQuickViewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{product.name}</DialogTitle>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full rounded-lg"
              />
              <div className="grid grid-cols-4 gap-2">
                {product.images.slice(1).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`${product.name} ${index + 2}`}
                    className="w-full aspect-square object-cover rounded"
                  />
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-2xl font-bold">${product.price.toFixed(2)}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={
                          i < Math.floor(product.rating)
                            ? 'fill-black text-black'
                            : 'text-gray-300'
                        }
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">
                    {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>
              </div>
              <p className="text-gray-600">{product.description}</p>
              <div>
                <p className="text-sm font-medium mb-2">Available Sizes:</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <span
                      key={size}
                      className="px-3 py-1 border rounded text-sm"
                    >
                      {size}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Available Colors:</p>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((color) => (
                    <span
                      key={color}
                      className="px-3 py-1 border rounded text-sm"
                    >
                      {color}
                    </span>
                  ))}
                </div>
              </div>
              <Button asChild className="w-full bg-black text-white hover:bg-gray-800">
                <Link to={`/product/${product.id}`}>View Full Details</Link>
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
